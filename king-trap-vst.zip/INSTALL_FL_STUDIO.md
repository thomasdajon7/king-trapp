# Install 1o1 DARK SYNTH in FL Studio

You get **two installable things** when you build this kit:
1. **1o1 DARK SYNTH.vst3** — the plugin you load inside FL Studio (and any DAW).
2. **1o1 DARK SYNTH (Standalone)** — a standalone **application** you can run on its own without any DAW.

---

## A) Get the files
- **Easiest (no tools):** push this `vst-native` folder to GitHub → open the **Actions** tab → let *Build 1o1 DARK SYNTH* run → download the **artifact** for your OS (Windows or macOS). It contains the `.vst3`, the Standalone app, and (mac) the `.component` AU.
- **Local build:** run `build_windows.bat` (Windows) or `./build_mac.sh` (macOS). Output lands in `build/1o1DarkSynth_artefacts/Release/`.

---

## B) Install the plugin

> **VST3 vs VST2:** FL Studio supports both. This kit builds **VST3** by default (recommended, modern). **VST2** (`.dll`) is optional and needs Steinberg's proprietary VST2 SDK — enable it by building with `-DVST2_SDK_PATH=/path/to/VST2_SDK`, then the `.dll` appears in the `VST/` output folder; copy it to your VST2 folder (e.g. `C:\Program Files\VstPlugins\` or FL's *File settings → VST2 plugins search path*).

### Windows
1. Copy `1o1 DARK SYNTH.vst3` into: `C:\Program Files\Common Files\VST3\`
2. Open **FL Studio** → **Options → Manage plugins**.
3. Under *Plugin search paths*, make sure `C:\Program Files\Common Files\VST3` is listed.
4. Click **Find installed plugins** (Verify/Scan).
5. In the plugin picker, search **"1o1 DARK SYNTH"** (manufacturer **1o1 Audio**).

### macOS
1. `build_mac.sh` auto-copies to `~/Library/Audio/Plug-Ins/VST3/` and `~/Library/Audio/Plug-Ins/Components/`.
2. FL Studio → **Options → Manage plugins → Find installed plugins**.
3. Search **"1o1 DARK SYNTH"**.
> If macOS blocks it (unsigned), right‑click the app → **Open** once, or run:
> `xattr -dr com.apple.quarantine "~/Library/Audio/Plug-Ins/VST3/1o1 DARK SYNTH.vst3"`

---

## C) Use it
1. Add it to a channel (drag from the plugin picker to the Channel Rack).
2. Draw notes in the Piano Roll or play your MIDI keyboard.
3. Pick an **Engine** (Subtractive / FM / Wavetable) and tweak the knobs.

## D) Run the Standalone application (no DAW)
- **Windows:** run `1o1 DARK SYNTH.exe` from `build\...\Standalone\`.
- **macOS:** open `1o1 DARK SYNTH.app` from `build/.../Standalone/`.
- Set your audio device in the app's options and play with a MIDI keyboard.

---

### Troubleshooting
- **Not showing in FL Studio** → confirm the `.vst3` is in the VST3 folder, then re‑run *Find installed plugins*.
- **No sound** → check the Standalone app's audio-device settings, or in FL that the channel is routed to the Master.
- **macOS "damaged" warning** → it's just unsigned; use the `xattr` command above.
