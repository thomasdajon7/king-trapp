#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class NexusLookAndFeel : public juce::LookAndFeel_V4
{
public:
    NexusLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h,
                           float pos, float startAngle, float endAngle,
                           juce::Slider&) override;
    void drawComboBox (juce::Graphics&, int width, int height, bool isDown,
                       int buttonX, int buttonY, int buttonW, int buttonH,
                       juce::ComboBox&) override;
    juce::Font getComboBoxFont (juce::ComboBox&) override;
    juce::Font getLabelFont (juce::Label&) override;
};

// simple reusable list model driven by lambdas
struct LcdListModel : public juce::ListBoxModel
{
    std::function<int()> numRows;
    std::function<juce::String (int)> rowText;
    std::function<void (int)> onSelect;
    int getNumRows() override { return numRows ? numRows() : 0; }
    void paintListBoxItem (int row, juce::Graphics& g, int w, int h, bool sel) override;
    void listBoxItemClicked (int row, const juce::MouseEvent&) override { if (onSelect) onSelect (row); }
};

class DarkSynthEditor : public juce::AudioProcessorEditor
{
public:
    explicit DarkSynthEditor (DarkSynthProcessor&);
    ~DarkSynthEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAtt = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAtt  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    struct Ctl { juce::Slider slider; juce::Label label; std::unique_ptr<SliderAtt> att; };

    void addKnob (const juce::String& id, const juce::String& name);
    void layoutKnobs (juce::Rectangle<int> area, int start, int count, int cols);
    void setParam (const juce::String& id, float actual);
    void rebuildFiltered();
    void applyPreset (int filteredRow);

    DarkSynthProcessor& proc;
    juce::OwnedArray<Ctl> knobs;

    juce::ComboBox engineBox, osc1Box, osc2Box, filterBox;
    std::unique_ptr<ComboAtt> engineAtt, osc1Att, osc2Att, filterAtt;

    juce::StringArray categories;
    int selectedCat = 0;
    juce::Array<int> filtered;
    juce::String currentPresetName = "-- INIT --";

    juce::ListBox catBox, presetBox;
    LcdListModel catModel, presetModel;

    NexusLookAndFeel lnf;
    juce::Rectangle<int> rFilter, rOsc, rAmp, rFm, rBottom, rLcd;

    juce::MidiKeyboardComponent keyboard { proc.keyboardState, juce::MidiKeyboardComponent::horizontalKeyboard };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DarkSynthEditor)
};
