#pragma once
#include <JuceHeader.h>

//==============================================================================
// One synth voice supporting three engines: Subtractive, FM, Wavetable.
//==============================================================================
struct SteamSound : public juce::SynthesiserSound
{
    bool appliesToNote (int) override    { return true; }
    bool appliesToChannel (int) override { return true; }
};

class SteamVoice : public juce::SynthesiserVoice
{
public:
    SteamVoice (juce::AudioProcessorValueTreeState& s) : apvts (s) {}

    bool canPlaySound (juce::SynthesiserSound* sound) override
    {
        return dynamic_cast<SteamSound*> (sound) != nullptr;
    }

    void startNote (int midiNote, float velocity, juce::SynthesiserSound*, int) override
    {
        frequency = juce::MidiMessage::getMidiNoteInHertz (midiNote);
        level = velocity;
        phase1 = phase2 = phaseMod = 0.0;
        adsr.noteOn();
    }

    void stopNote (float, bool allowTailOff) override
    {
        adsr.noteOff();
        if (! allowTailOff || ! adsr.isActive())
            clearCurrentNote();
    }

    void pitchWheelMoved (int) override {}
    void controllerMoved (int, int) override {}

    void prepare (double sampleRate, int blockSize, int numCh)
    {
        adsr.setSampleRate (sampleRate);
        juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) blockSize, (juce::uint32) numCh };
        filter.prepare (spec);
        filter.reset();
        sr = sampleRate;
    }

    static float poly (double phase, int type) // 0 sine 1 saw 2 square 3 tri
    {
        double t = phase / juce::MathConstants<double>::twoPi;
        switch (type)
        {
            case 0: return (float) std::sin (phase);
            case 1: return (float) (2.0 * t - 1.0);
            case 2: return t < 0.5 ? 1.0f : -1.0f;
            default: return (float) (4.0 * std::abs (t - 0.5) - 1.0);
        }
    }

    void renderNextBlock (juce::AudioBuffer<float>& out, int start, int num) override
    {
        if (! isVoiceActive()) return;

        const int engine   = (int) *apvts.getRawParameterValue ("engine");
        const int w1        = (int) *apvts.getRawParameterValue ("osc1Wave");
        const int w2        = (int) *apvts.getRawParameterValue ("osc2Wave");
        const float det1    = *apvts.getRawParameterValue ("osc1Detune");
        const float det2    = *apvts.getRawParameterValue ("osc2Detune");
        const float mix     = *apvts.getRawParameterValue ("oscMix");
        const float fmRatio = *apvts.getRawParameterValue ("fmRatio");
        const float fmIndex = *apvts.getRawParameterValue ("fmIndex");
        const float wavePos = *apvts.getRawParameterValue ("wavePos");
        const float cutoff  = *apvts.getRawParameterValue ("cutoff");
        const float reso    = *apvts.getRawParameterValue ("resonance");
        const int   ftype   = (int) *apvts.getRawParameterValue ("filterType");

        adsr.setParameters ({ *apvts.getRawParameterValue ("attack"),
                              *apvts.getRawParameterValue ("decay"),
                              *apvts.getRawParameterValue ("sustain"),
                              *apvts.getRawParameterValue ("release") });

        filter.setCutoffFrequency (juce::jlimit (20.0f, 18000.0f, cutoff));
        filter.setResonance (juce::jlimit (0.1f, 1.2f, reso / 18.0f + 0.1f));
        filter.setType (ftype == 1 ? juce::dsp::StateVariableTPTFilterType::highpass
                       : ftype == 2 ? juce::dsp::StateVariableTPTFilterType::bandpass
                                    : juce::dsp::StateVariableTPTFilterType::lowpass);

        const double inc1 = juce::MathConstants<double>::twoPi
                          * frequency * std::pow (2.0, det1 / 12.0) / sr;
        const double inc2 = juce::MathConstants<double>::twoPi
                          * frequency * std::pow (2.0, det2 / 12.0) / sr;
        const double incMod = juce::MathConstants<double>::twoPi * frequency * fmRatio / sr;

        for (int i = 0; i < num; ++i)
        {
            float s = 0.0f;

            if (engine == 1) // FM
            {
                double modV = std::sin (phaseMod) * fmIndex;
                s = (float) std::sin (phase1 + modV);
                phaseMod += incMod;
            }
            else if (engine == 2) // Wavetable (sine<->saw morph)
            {
                float a = poly (phase1, 0);
                float b = poly (phase1, 1);
                float o1 = a * (1.0f - wavePos) + b * wavePos;
                float o2s = poly (phase2, 1);
                s = o1 * (1.0f - mix) + o2s * mix;
            }
            else // Subtractive
            {
                s = poly (phase1, w1) * (1.0f - mix) + poly (phase2, w2) * mix;
            }

            phase1 += inc1; if (phase1 > juce::MathConstants<double>::twoPi) phase1 -= juce::MathConstants<double>::twoPi;
            phase2 += inc2; if (phase2 > juce::MathConstants<double>::twoPi) phase2 -= juce::MathConstants<double>::twoPi;

            float env = adsr.getNextSample();
            float filtered = filter.processSample (0, s);
            float outSamp = filtered * env * level * 0.35f;

            for (int ch = 0; ch < out.getNumChannels(); ++ch)
                out.addSample (ch, start + i, outSamp);

            if (! adsr.isActive()) { clearCurrentNote(); break; }
        }
    }

private:
    juce::AudioProcessorValueTreeState& apvts;
    juce::ADSR adsr;
    juce::dsp::StateVariableTPTFilter<float> filter;
    double sr = 44100.0, frequency = 440.0;
    double phase1 = 0.0, phase2 = 0.0, phaseMod = 0.0;
    float level = 0.8f;
};
